// Martin Herrera - Alvarado 1/16/25 Ch1 Assignment1
package ch1assignment1;

public class Triangle {

	public static void main(String[] args) {
		System.out.println("      T");
		System.out.println("     TTT");
		System.out.println("    TTTTT");
		System.out.println("   TTTTTTT");
		System.out.println("  TTTTTTTTT");
		System.out.println(" TTTTTTTTTTT");
		System.out.println("TTTTTTTTTTTTT");
		
	}

}
