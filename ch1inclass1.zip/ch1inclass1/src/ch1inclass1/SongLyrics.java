// Martin Herrera - Alvarado 1/16/25 inclass 1 ch1
package ch1inclass1;

public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("They tell me to keep it simple");
		System.out.println("I tell them, Take it slow");
		System.out.println("I feed and water an idea so i let it grow");
		System.out.println("I tell them, Take it easy");
	}

}
