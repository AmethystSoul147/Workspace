// Martin Herrera - Alvarado 1/16/25 ch 1 inclass 2
package ch1inclass2;

public class MovieQuote {

	public static void main(String[] args) {
		System.out.println("Harry Potter and the Sorcerer's Stone");
		System.out.println("Yer a wizard, Harry");
		System.out.println("Rubeus Hagrid");
		System.out.println("Year 2001");
		
	}

}
