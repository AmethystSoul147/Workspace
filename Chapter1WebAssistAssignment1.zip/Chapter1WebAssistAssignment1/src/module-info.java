/**
 * 
 */
/**
 * 
 */
module Chapter1WebAssistAssignment1 {
	requires java.desktop;
}